/** @type {import('next').NextConfig} */
const nextConfig = {
  // Ajouter une configuration pour les actifs statiques

  async headers() {
    return [
      {
        source: '/fonts/(.*)',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, max-age=31536000, immutable',
          },
        ],
      },
    ];
  },
};

export default nextConfig;
