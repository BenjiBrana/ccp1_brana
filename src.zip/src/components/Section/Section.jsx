export default function Section({ children }) {
  return children;
}
